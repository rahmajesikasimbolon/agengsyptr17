<?php
//koneksi ke database
$conn = mysqli_connect("localhost", "root", "root", "phpdasar");

function query($query) {
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while($row = mysqli_fetch_assoc($result)) {
        $rows[] = $rows;
   
    }
    return $rows;
}


function tambah ($data) {
    global $conn;

    $nrp = htmlspecialchars($data["nrp"]);
    $nama = htmlspecialchars($data["nama"]);
    $email = htmlspecialchars($data["email"];
    $jurusan= htmlspecialchars($data["jurusan"];
    $gambar=  htmlspecialchars($data["email"];
    
    $query = "INSERT INTO mahasiswa 
                VALUES
              ('', '$nrp', '$nama', '$email', '$jurusan', '$gambar',)
            ";             
    mysqli_connect($conn, $query);


    return mysqli_affected_rows($conn);
}



?>